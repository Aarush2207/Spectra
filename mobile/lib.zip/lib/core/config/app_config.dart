/// Central application configuration.
/// Configures direct Supabase and Gemini AI services without requiring a local backend server.
class AppConfig {
  AppConfig._();

  // ─── Gemini AI ───────────────────────────────────────────────────────────────
  /// Google Gemini API key for direct client-side scam analysis & multimodal vision
  static const String geminiApiKey = String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: 'AQ.Ab8RN6ICQAy-hEcCiaFE3O3E115pslm9ELYh940sWqC1ZmE1aw',
  );

  // ─── Supabase ────────────────────────────────────────────────────────────────
  /// Supabase project URL
  static const String supabaseUrl = 'https://lelmcuezksfeblhfrcmy.supabase.co';

  /// Supabase publishable key
  static const String supabasePublishableKey =
      'sb_publishable_b7fhiEUZlkKjesrPt4qTPA_YdFDUxAo';

  /// Backwards compatibility alias
  static const String supabaseAnonKey = supabasePublishableKey;

  // ─── Limits ─────────────────────────────────────────────────────────────────
  static const int maxImageSizeBytes = 10 * 1024 * 1024; // 10 MB
  static const int networkTimeoutSeconds = 60;
  static const int minTextLength = 10;
  static const List<String> allowedImageExtensions = ['jpg', 'jpeg', 'png', 'webp'];
}
