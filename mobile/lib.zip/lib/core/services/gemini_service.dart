import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import '../config/app_config.dart';

const String _systemPrompt = '''
You are Spectra AI, a specialized cybersecurity scam and phishing detection engine.
Analyze the user's input text (or screenshot) for signs of:
1. Phishing attempts & credential harvesting
2. Artificial urgency & manufactured panic
3. Impersonation of trusted authorities, banks, government, or services
4. Unsolicited offers, lottery scams, cryptocurrency fraud
5. Requests for sensitive data (OTP, password, PIN, banking details)
6. Suspicious links or deceptive redirects

CRITICAL INSTRUCTIONS:
- You MUST output valid, raw JSON only. Do not include markdown codeblocks or extra text.
- Follow this exact JSON schema:
{
  "risk_level": "LOW" | "SUSPICIOUS" | "HIGH",
  "risk_score": <integer from 0 to 100>,
  "confidence": "HIGH" | "MEDIUM" | "LOW",
  "summary": "<2-3 sentence clear explanation>",
  "evidence": [
    {
      "phrase": "<exact or near exact phrase from message>",
      "reason": "<specific threat reason e.g. Manufactured urgency, Impersonation>",
      "severity": "HIGH" | "MEDIUM" | "LOW"
    }
  ],
  "recommendations": [
    "<actionable safety tip 1>",
    "<actionable safety tip 2>"
  ]
}
- If evidence is insufficient, mark risk_level as "LOW" or "SUSPICIOUS" with appropriate confidence. Never label a message 100% safe.
''';

class GeminiService {
  final Dio _dio;
  final String apiKey;
  final List<String> models = const [
    'gemini-1.5-flash',
    'gemini-2.0-flash',
    'gemini-1.5-pro',
  ];

  GeminiService({Dio? dio, String? apiKey})
      : _dio = dio ??
            Dio(
              BaseOptions(
                connectTimeout: const Duration(seconds: 30),
                receiveTimeout: const Duration(seconds: 60),
                sendTimeout: const Duration(seconds: 60),
                headers: {'Content-Type': 'application/json'},
              ),
            ),
        apiKey = apiKey ?? AppConfig.geminiApiKey;

  /// Analyzes text message directly via Google Generative AI
  Future<Map<String, dynamic>> analyzeText(String text) async {
    if (apiKey.isEmpty) {
      return _heuristicFallback(text, 'Gemini API key is not configured.');
    }

    final payload = {
      'contents': [
        {
          'parts': [
            {'text': '$_systemPrompt\n\nAnalyze this suspicious message:\n"""$text"""'}
          ]
        }
      ],
      'generationConfig': {
        'response_mime_type': 'application/json',
        'temperature': 0.2,
      }
    };

    return _callGemini(payload, text);
  }

  /// Analyzes a screenshot image directly via Google Generative AI Multimodal Vision
  Future<Map<String, dynamic>> analyzeImage(File imageFile) async {
    if (apiKey.isEmpty) {
      return _heuristicFallback('Screenshot OCR Analysis', 'Gemini API key is not configured.');
    }

    if (!imageFile.existsSync()) {
      return _heuristicFallback('Screenshot OCR Analysis', 'Image file does not exist on device.');
    }

    try {
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);

      // Determine mime type from extension
      final ext = imageFile.path.split('.').last.toLowerCase();
      final mimeType = ext == 'png'
          ? 'image/png'
          : ext == 'webp'
              ? 'image/webp'
              : 'image/jpeg';

      final payload = {
        'contents': [
          {
            'parts': [
              {
                'text':
                    '$_systemPrompt\n\nPerform OCR text extraction on this screenshot and thoroughly analyze it for cybersecurity threats, scams, and urgency patterns.'
              },
              {
                'inline_data': {
                  'mime_type': mimeType,
                  'data': base64Image,
                }
              }
            ]
          }
        ],
        'generationConfig': {
          'response_mime_type': 'application/json',
          'temperature': 0.2,
        }
      };

      return await _callGemini(payload, 'Screenshot Analysis');
    } catch (e) {
      return _heuristicFallback('Screenshot Analysis', 'Image processing error: ${e.toString()}');
    }
  }

  /// Iterates through fallback Gemini models with prompt payload
  Future<Map<String, dynamic>> _callGemini(Map<String, dynamic> payload, String fallbackInput) async {
    for (final model in models) {
      final url =
          'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey';

      try {
        final response = await _dio.post(url, data: payload);
        if (response.statusCode == 200 && response.data != null) {
          final data = response.data as Map<String, dynamic>;
          final candidates = data['candidates'] as List<dynamic>?;
          if (candidates != null && candidates.isNotEmpty) {
            final content = candidates[0]['content'] as Map<String, dynamic>?;
            final parts = content?['parts'] as List<dynamic>?;
            if (parts != null && parts.isNotEmpty) {
              final textOut = (parts[0]['text'] as String? ?? '').trim();
              final cleaned = _extractJson(textOut);
              final parsed = jsonDecode(cleaned) as Map<String, dynamic>;
              return _validateAndNormalize(parsed);
            }
          }
        }
      } on DioException catch (e) {
        final errDetail = e.response?.data?.toString() ?? e.message;
        // ignore: avoid_print
        print('[Spectra Gemini] Model $model failed (${e.response?.statusCode}): $errDetail');
        continue;
      } catch (e) {
        // ignore: avoid_print
        print('[Spectra Gemini] Model $model error: $e');
        continue;
      }
    }

    // Heuristic fallback if remote model is unreachable
    return _heuristicFallback(fallbackInput, 'AI cloud service was temporarily unreachable.');
  }

  /// Extracts the outermost JSON object string, ignoring markdown markers or preamble/postscript text
  String _extractJson(String text) {
    var s = text.trim();
    final blockMatch = RegExp(r'```(?:json)?\s*([\s\S]*?)\s*```').firstMatch(s);
    if (blockMatch != null) {
      s = blockMatch.group(1)?.trim() ?? s;
    }
    final firstBrace = s.indexOf('{');
    final lastBrace = s.lastIndexOf('}');
    if (firstBrace != -1 && lastBrace != -1 && lastBrace > firstBrace) {
      s = s.substring(firstBrace, lastBrace + 1);
    }
    return s;
  }

  Map<String, dynamic> _validateAndNormalize(Map<String, dynamic> data) {
    var riskLevel = (data['risk_level'] as String? ?? 'SUSPICIOUS').toUpperCase();
    if (riskLevel == 'MEDIUM') riskLevel = 'SUSPICIOUS';
    if (!['LOW', 'SUSPICIOUS', 'HIGH', 'UNKNOWN'].contains(riskLevel)) {
      riskLevel = 'SUSPICIOUS';
    }

    int? riskScore;
    final rawScore = data['risk_score'];
    if (rawScore is num) {
      if (rawScore > 0 && rawScore <= 1.0) {
        riskScore = (rawScore * 100).round();
      } else {
        riskScore = rawScore.round().clamp(0, 100);
      }
    } else if (rawScore != null) {
      final parsed = double.tryParse(rawScore.toString());
      if (parsed != null) {
        riskScore = (parsed <= 1.0 && parsed > 0)
            ? (parsed * 100).round()
            : parsed.round().clamp(0, 100);
      } else {
        riskScore = 50;
      }
    }

    var confidence = (data['confidence'] as String? ?? 'MEDIUM').toUpperCase();
    if (!['HIGH', 'MEDIUM', 'LOW'].contains(confidence)) {
      confidence = 'MEDIUM';
    }

    final summary = (data['summary'] as String?)?.isNotEmpty == true
        ? data['summary'] as String
        : 'Analysis completed by Spectra AI engine.';

    final rawEvidence = data['evidence'] as List<dynamic>? ?? [];
    final evidence = <Map<String, dynamic>>[];
    for (final e in rawEvidence) {
      if (e is Map<String, dynamic>) {
        var sev = (e['severity'] as String? ?? 'MEDIUM').toUpperCase();
        if (!['HIGH', 'MEDIUM', 'LOW'].contains(sev)) sev = 'MEDIUM';
        evidence.add({
          'phrase': e['phrase']?.toString() ?? '',
          'reason': e['reason']?.toString() ?? 'Suspicious pattern detected',
          'severity': sev,
        });
      }
    }

    final rawRecs = data['recommendations'] as List<dynamic>? ?? [];
    final recommendations = rawRecs.map((r) => r.toString()).toList();

    return {
      'risk_level': riskLevel,
      'risk_score': riskScore ?? 50,
      'confidence': confidence,
      'summary': summary,
      'evidence': evidence,
      'recommendations': recommendations.isNotEmpty
          ? recommendations
          : [
              'Do not click any unverified links.',
              'Never share OTPs, passwords, or personal credentials.',
              'Verify message authenticity with the official service provider.',
            ],
    };
  }

  Map<String, dynamic> _heuristicFallback(String text, String reason) {
    final lower = text.toLowerCase();
    final evidence = <Map<String, dynamic>>[];
    String riskLevel = 'LOW';
    int riskScore = 15;

    const highRiskWords = [
      MapEntry('otp', 'Sensitive credential solicitation'),
      MapEntry('password', 'Credential harvesting indicator'),
      MapEntry('account blocked', 'Manufactured panic / urgency'),
      MapEntry('debit card', 'Financial credential request'),
      MapEntry('lottery won', 'Lottery / advance fee fraud pattern'),
      MapEntry('kyc expired', 'KYC / banking impersonation'),
      MapEntry('arrest warrant', 'Coercive legal threat impersonation'),
    ];

    const suspiciousWords = [
      MapEntry('urgent', 'Artificial urgency'),
      MapEntry('immediately', 'Time pressure tactic'),
      MapEntry('click here', 'Unsolicited link prompt'),
      MapEntry('verify now', 'Call to action prompt'),
      MapEntry('congratulations', 'Unsolicited reward pattern'),
    ];

    for (final entry in highRiskWords) {
      if (lower.contains(entry.key)) {
        evidence.add({'phrase': entry.key, 'reason': entry.value, 'severity': 'HIGH'});
        riskLevel = 'HIGH';
        riskScore = 88;
      }
    }

    for (final entry in suspiciousWords) {
      if (lower.contains(entry.key)) {
        evidence.add({'phrase': entry.key, 'reason': entry.value, 'severity': 'MEDIUM'});
        if (riskLevel != 'HIGH') {
          riskLevel = 'SUSPICIOUS';
          riskScore = 55;
        }
      }
    }

    final summary = evidence.isNotEmpty
        ? 'Rule-based detection identified ${evidence.length} threat indicator(s). ($reason)'
        : 'No prominent threat patterns detected by rule inspection. ($reason)';

    return {
      'risk_level': riskLevel,
      'risk_score': riskScore,
      'confidence': 'MEDIUM',
      'summary': summary,
      'evidence': evidence,
      'recommendations': [
        'Verify any urgent claims through official customer service channels.',
        'Never share PINs, OTPs, or passwords under any circumstances.',
        'Do not open suspicious links or attachments.',
      ],
    };
  }
}
