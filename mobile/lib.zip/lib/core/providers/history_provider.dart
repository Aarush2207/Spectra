import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/supabase/supabase_service.dart';
import '../../models/scan_history_item.dart';

final historyProvider =
    StateNotifierProvider<HistoryNotifier, List<ScanHistoryItem>>(
  (ref) => HistoryNotifier(),
);

class HistoryNotifier extends StateNotifier<List<ScanHistoryItem>> {
  HistoryNotifier() : super([]) {
    loadHistory();
  }

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  /// Load scan history from Supabase.
  Future<void> loadHistory() async {
    if (!SupabaseService.isAuthenticated) {
      state = [];
      return;
    }

    _isLoading = true;
    try {
      final items = await SupabaseService.fetchScanHistory();
      state = items;
    } catch (e) {
      // Silently fail — history is not critical
      state = [];
    } finally {
      _isLoading = false;
    }
  }

  /// Remove a single scan by ID (cascade deletes evidence/urls/recs).
  Future<void> removeItem(String id) async {
    // Optimistic removal from UI
    state = state.where((i) => i.id != id).toList();
    try {
      await SupabaseService.deleteScan(id);
    } catch (_) {
      // Reload to resync if delete failed
      await loadHistory();
    }
  }

  /// Clear all scans for the current user.
  Future<void> clearAll() async {
    state = [];
    try {
      await SupabaseService.clearAllScans();
    } catch (_) {
      await loadHistory();
    }
  }
}
