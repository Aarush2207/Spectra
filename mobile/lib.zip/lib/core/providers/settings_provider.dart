import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  final bool onboardingComplete;
  final bool historyConsentGiven;

  const AppSettings({
    this.onboardingComplete = false,
    this.historyConsentGiven = false,
  });

  AppSettings copyWith({bool? onboardingComplete, bool? historyConsentGiven}) =>
      AppSettings(
        onboardingComplete: onboardingComplete ?? this.onboardingComplete,
        historyConsentGiven: historyConsentGiven ?? this.historyConsentGiven,
      );
}

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier() : super(const AppSettings()) {
    _load();
  }

  static const _keyOnboarding = 'onboarding_complete';
  static const _keyConsent = 'history_consent';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = AppSettings(
      onboardingComplete: prefs.getBool(_keyOnboarding) ?? false,
      historyConsentGiven: prefs.getBool(_keyConsent) ?? false,
    );
  }

  Future<void> completeOnboarding() async {
    state = state.copyWith(onboardingComplete: true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyOnboarding, true);
  }

  Future<void> setHistoryConsent(bool value) async {
    state = state.copyWith(historyConsentGiven: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyConsent, value);
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, AppSettings>(
  (_) => SettingsNotifier(),
);
