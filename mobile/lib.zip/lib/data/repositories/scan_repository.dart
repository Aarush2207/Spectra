import 'dart:io';
import '../../core/services/gemini_service.dart';
import '../../core/services/url_inspector.dart';
import '../../models/evidence.dart';
import '../../models/scan_result.dart';
import '../../models/suspicious_url.dart';

/// Repository that performs direct, standalone scam analysis in Flutter
/// using Gemini AI + Pure Dart Passive URL Inspector.
/// Does NOT require a local backend server to be running.
class ScanRepository {
  final GeminiService _gemini;

  ScanRepository({GeminiService? gemini})
      : _gemini = gemini ?? GeminiService();

  Future<ScanResult> analyzeText(String text) async {
    // 1. Passive URL inspection on any URLs within text
    final extractedUrls = UrlInspector.extractUrls(text);
    final urlFindings = extractedUrls.map(UrlInspector.inspect).toList();

    // 2. AI contextual analysis via Gemini
    final aiResult = await _gemini.analyzeText(text);

    // 3. Elevate risk if high-risk or suspicious URLs found
    var riskLevelStr = aiResult['risk_level'] as String? ?? 'LOW';
    var riskScore = aiResult['risk_score'] as int? ?? 50;

    final hasHighUrl = urlFindings.any((u) => u.risk == 'HIGH');
    final hasSuspiciousUrl = urlFindings.any((u) => u.risk == 'SUSPICIOUS');

    if (hasHighUrl) {
      riskLevelStr = 'HIGH';
      riskScore = (riskScore < 85) ? 85 : riskScore;
    } else if (hasSuspiciousUrl && riskLevelStr == 'LOW') {
      riskLevelStr = 'SUSPICIOUS';
      riskScore = (riskScore < 60) ? 60 : riskScore;
    }

    final evidence = (aiResult['evidence'] as List<dynamic>? ?? [])
        .map((e) => Evidence(
              phrase: e['phrase']?.toString() ?? '',
              reason: e['reason']?.toString() ?? '',
              severity: e['severity']?.toString() ?? 'MEDIUM',
            ))
        .toList();

    final recs = (aiResult['recommendations'] as List<dynamic>? ?? [])
        .map((r) => r.toString())
        .toList();

    return ScanResult(
      riskLevel: RiskLevelExt.fromString(riskLevelStr),
      riskScore: riskScore,
      confidence: aiResult['confidence']?.toString() ?? 'MEDIUM',
      summary: aiResult['summary']?.toString() ?? 'Analysis completed.',
      evidence: evidence,
      urls: urlFindings,
      recommendations: recs,
      timestamp: DateTime.now(),
    );
  }

  Future<ScanResult> analyzeImage(File imageFile) async {
    // 1. Multimodal OCR + AI analysis via Gemini Vision
    final aiResult = await _gemini.analyzeImage(imageFile);

    final evidence = (aiResult['evidence'] as List<dynamic>? ?? [])
        .map((e) => Evidence(
              phrase: e['phrase']?.toString() ?? '',
              reason: e['reason']?.toString() ?? '',
              severity: e['severity']?.toString() ?? 'MEDIUM',
            ))
        .toList();

    // 2. Extract and inspect any URLs found in OCR summary or evidence phrases
    final urlFindings = <SuspiciousUrl>[];
    final textSamples = [
      aiResult['summary']?.toString() ?? '',
      ...evidence.map((e) => e.phrase),
    ];

    for (final sample in textSamples) {
      for (final u in UrlInspector.extractUrls(sample)) {
        if (!urlFindings.any((item) => item.url == u)) {
          urlFindings.add(UrlInspector.inspect(u));
        }
      }
    }

    final recs = (aiResult['recommendations'] as List<dynamic>? ?? [])
        .map((r) => r.toString())
        .toList();

    return ScanResult(
      riskLevel: RiskLevelExt.fromString(aiResult['risk_level']?.toString() ?? 'SUSPICIOUS'),
      riskScore: aiResult['risk_score'] as int? ?? 65,
      confidence: aiResult['confidence']?.toString() ?? 'MEDIUM',
      summary: aiResult['summary']?.toString() ?? 'Screenshot analysis completed.',
      evidence: evidence,
      urls: urlFindings,
      recommendations: recs,
      timestamp: DateTime.now(),
    );
  }

  Future<ScanResult> analyzeUrl(String rawUrl) async {
    // 1. Passive URL inspection
    final urlFinding = UrlInspector.inspect(rawUrl);

    // 2. AI contextual analysis
    final aiPrompt =
        'Analyze this URL for potential scam, phishing, brand spoofing, or security threat: $rawUrl';
    final aiResult = await _gemini.analyzeText(aiPrompt);

    var riskLevelStr = aiResult['risk_level'] as String? ?? 'LOW';
    var riskScore = aiResult['risk_score'] as int? ?? 50;

    if (urlFinding.risk == 'HIGH') {
      riskLevelStr = 'HIGH';
      riskScore = (riskScore < 85) ? 85 : riskScore;
    } else if (urlFinding.risk == 'SUSPICIOUS' && riskLevelStr == 'LOW') {
      riskLevelStr = 'SUSPICIOUS';
      riskScore = (riskScore < 60) ? 60 : riskScore;
    }

    final evidence = (aiResult['evidence'] as List<dynamic>? ?? [])
        .map((e) => Evidence(
              phrase: e['phrase']?.toString() ?? '',
              reason: e['reason']?.toString() ?? '',
              severity: e['severity']?.toString() ?? 'MEDIUM',
            ))
        .toList();

    final recs = (aiResult['recommendations'] as List<dynamic>? ?? [])
        .map((r) => r.toString())
        .toList();

    return ScanResult(
      riskLevel: RiskLevelExt.fromString(riskLevelStr),
      riskScore: riskScore,
      confidence: aiResult['confidence']?.toString() ?? 'MEDIUM',
      summary: aiResult['summary']?.toString() ?? 'URL analysis completed.',
      evidence: evidence,
      urls: [urlFinding],
      recommendations: recs.isNotEmpty
          ? recs
          : [
              'Do not click or open unverified links.',
              'Verify the website address by searching for the official company site.',
              'Check for valid HTTPS encryption before submitting any credentials.',
            ],
      timestamp: DateTime.now(),
    );
  }

  Future<bool> healthCheck() async {
    return _gemini.apiKey.isNotEmpty;
  }
}
