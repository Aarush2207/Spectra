import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/history_provider.dart';
import '../../core/services/gemini_service.dart';
import '../../core/widgets/glass_card.dart';
import '../../core/widgets/spectra_logo.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppColors.primaryBg,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: _ProfileHeader(authState: authState),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Auth section
                _AuthSection(authState: authState, ref: ref)
                    .animate()
                    .fadeIn(delay: 200.ms, duration: 500.ms),
                const SizedBox(height: 18),

                // Cloud services status
                const _CloudServicesSection()
                    .animate()
                    .fadeIn(delay: 280.ms, duration: 500.ms),
                const SizedBox(height: 18),

                _AboutSection()
                    .animate()
                    .fadeIn(delay: 350.ms, duration: 500.ms),
                const SizedBox(height: 18),
                _SecuritySection()
                    .animate()
                    .fadeIn(delay: 450.ms, duration: 500.ms),
                const SizedBox(height: 18),
                _DataSection(ref: ref)
                    .animate()
                    .fadeIn(delay: 600.ms, duration: 500.ms),
                const SizedBox(height: 18),
                _DisclaimerSection()
                    .animate()
                    .fadeIn(delay: 750.ms, duration: 500.ms),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  final AuthState authState;

  const _ProfileHeader({required this.authState});

  @override
  Widget build(BuildContext context) {
    final user = authState.user;
    final email = user?.email ?? 'Guest User';
    final name = user?.userMetadata?['display_name'] as String?;

    return Container(
      padding: EdgeInsets.fromLTRB(
          20, MediaQuery.of(context).padding.top + 20, 20, 24),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.secondaryBg, AppColors.primaryBg],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        children: [
          const SpectraLogo(size: 72, animated: true),
          const SizedBox(height: 14),
          ShaderMask(
            shaderCallback: (b) => AppColors.primaryGradient.createShader(b),
            child: const Text(
              AppStrings.appName,
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w900,
                letterSpacing: 5,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'v${AppStrings.version}',
            style: TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
          const SizedBox(height: 12),
          // User info
          if (authState.status == AuthStatus.authenticated) ...[
            if (name != null && name.isNotEmpty)
              Text(
                name,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            const SizedBox(height: 4),
            Text(
              email,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 13,
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.warning.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.warning.withValues(alpha: 0.3)),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.person_outline_rounded,
                      color: AppColors.warning, size: 14),
                  SizedBox(width: 6),
                  Text(
                    'Guest Mode — Sign in to save scans',
                    style: TextStyle(
                      color: AppColors.warning,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 8),
          const Text(
            AppStrings.tagline,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12.5,
              height: 1.5,
            ),
          ),
        ],
      ),
    )
        .animate()
        .fadeIn(duration: 500.ms)
        .slideY(begin: -0.04, duration: 500.ms);
  }
}

// ─── Cloud Services Section ───────────────────────────────────────────────────
class _CloudServicesSection extends StatefulWidget {
  const _CloudServicesSection();

  @override
  State<_CloudServicesSection> createState() => _CloudServicesSectionState();
}

class _CloudServicesSectionState extends State<_CloudServicesSection> {
  bool _testing = false;
  String? _testResult;
  bool _isSuccess = false;

  Future<void> _testConnection() async {
    setState(() {
      _testing = true;
      _testResult = null;
    });

    try {
      final gemini = GeminiService();
      final result = await gemini.analyzeText('Test connectivity check');
      final isAiActive = result['risk_level'] != null;

      setState(() {
        _testing = false;
        _isSuccess = isAiActive;
        _testResult = isAiActive
            ? 'Supabase & Gemini AI connected directly!'
            : 'Service check returned inconclusive response.';
      });
    } catch (e) {
      setState(() {
        _testing = false;
        _isSuccess = false;
        _testResult = 'Connection check failed: ${e.toString()}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Cloud Services & AI Engine',
      icon: Icons.cloud_done_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),
          // Supabase row
          const _ServiceStatusTile(
            icon: Icons.bolt_rounded,
            color: AppColors.success,
            title: 'Supabase Cloud Database & Auth',
            subtitle: 'Direct connection • RLS Security Active',
          ),
          const SizedBox(height: 10),
          // Gemini row
          const _ServiceStatusTile(
            icon: Icons.auto_awesome_rounded,
            color: AppColors.primaryAccent,
            title: 'Google Gemini Multimodal AI',
            subtitle: 'Vision OCR & Threat Reasoning Active',
          ),
          const SizedBox(height: 10),
          // URL inspector row
          const _ServiceStatusTile(
            icon: Icons.shield_rounded,
            color: AppColors.secondaryAccent,
            title: 'Passive URL Inspection Engine',
            subtitle: 'Static Lexical Analysis (Zero External Navigation)',
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testing ? null : _testConnection,
                  icon: _testing
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.check_circle_outline_rounded, size: 16),
                  label: Text(_testing ? 'Verifying...' : 'Verify Cloud AI Services'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 42),
                    foregroundColor: AppColors.primaryAccent,
                  ),
                ),
              ),
            ],
          ),
          if (_testResult != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: (_isSuccess ? AppColors.success : AppColors.danger)
                    .withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: (_isSuccess ? AppColors.success : AppColors.danger)
                      .withValues(alpha: 0.25),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _isSuccess
                        ? Icons.check_circle_rounded
                        : Icons.error_outline_rounded,
                    color: _isSuccess ? AppColors.success : AppColors.danger,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _testResult!,
                      style: TextStyle(
                        color: _isSuccess ? AppColors.success : AppColors.danger,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ServiceStatusTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;

  const _ServiceStatusTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.secondaryBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Auth section ─────────────────────────────────────────────────────────────
class _AuthSection extends StatelessWidget {
  final AuthState authState;
  final WidgetRef ref;

  const _AuthSection({required this.authState, required this.ref});

  @override
  Widget build(BuildContext context) {
    if (authState.status == AuthStatus.authenticated) {
      return GlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.account_circle_rounded,
                    color: AppColors.success, size: 18),
                const SizedBox(width: 8),
                Text(
                  'Account',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.primaryAccent.withValues(alpha: 0.1),
                    border: Border.all(
                        color: AppColors.primaryAccent.withValues(alpha: 0.3)),
                  ),
                  child: Center(
                    child: Text(
                      (authState.user?.email?.substring(0, 1) ?? 'U')
                          .toUpperCase(),
                      style: const TextStyle(
                        color: AppColors.primaryAccent,
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        authState.user?.email ?? '',
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'Signed in • Scans are saved to your account',
                        style: TextStyle(
                            color: AppColors.textMuted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => _confirmSignOut(context),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.danger.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: AppColors.danger.withValues(alpha: 0.25)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.logout_rounded,
                        color: AppColors.danger, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Sign Out',
                      style: TextStyle(
                        color: AppColors.danger,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    } else {
      // Guest — show sign in prompt
      return GlassCard(
        child: Column(
          children: [
            const Icon(Icons.shield_rounded,
                color: AppColors.primaryAccent, size: 36),
            const SizedBox(height: 12),
            const Text(
              'Sign in to save your scan history',
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Your scans will be stored securely in the cloud and synced across devices.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: AppColors.textSecondary, fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => context.go('/auth'),
                icon: const Icon(Icons.login_rounded, size: 18),
                label: const Text('Sign In or Sign Up'),
              ),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _confirmSignOut(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: AppColors.cardBg,
        title: const Text('Sign Out?'),
        content: const Text(
          'You will need to sign in again to access your scan history.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(c, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
            ),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(authProvider.notifier).signOut();
    }
  }
}

class _AboutSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'About Spectra',
      icon: Icons.info_rounded,
      child: Padding(
        padding: const EdgeInsets.only(top: 12),
        child: const Text(
          AppStrings.aboutDescription,
          style: TextStyle(
            color: AppColors.textSecondary,
            fontSize: 13.5,
            height: 1.6,
          ),
        ),
      ),
    );
  }
}

class _SecuritySection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = const [
      _SecItem(Icons.lock_rounded, 'Never opens suspicious URLs'),
      _SecItem(Icons.no_photography_rounded,
          'Screenshots not stored by default'),
      _SecItem(Icons.key_off_rounded, 'Never collects passwords or PINs'),
      _SecItem(Icons.verified_user_rounded, 'Direct Supabase RLS security active'),
      _SecItem(Icons.fact_check_rounded,
          'All AI results treated as advisory only'),
    ];

    return _Section(
      title: 'Security Guidelines',
      icon: Icons.security_rounded,
      child: Column(
        children: items
            .map((item) => Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    children: [
                      Icon(item.icon, color: AppColors.success, size: 16),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          item.label,
                          style: const TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ))
            .toList(),
      ),
    );
  }
}

class _SecItem {
  final IconData icon;
  final String label;

  const _SecItem(this.icon, this.label);
}

class _DataSection extends StatelessWidget {
  final WidgetRef ref;

  const _DataSection({required this.ref});

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Data & Privacy',
      icon: Icons.privacy_tip_rounded,
      child: Column(
        children: [
          const SizedBox(height: 12),
          const Text(
            'Spectra stores only minimal metadata (risk level, date, scan type) '
            'with your explicit consent. No raw messages or screenshots are saved.',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 13,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () => _confirmClear(context),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.danger.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: AppColors.danger.withValues(alpha: 0.25)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.delete_forever_rounded,
                      color: AppColors.danger, size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Clear All Scan History',
                    style: TextStyle(
                      color: AppColors.danger,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmClear(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: AppColors.cardBg,
        title: const Text('Clear History?'),
        content: const Text(AppStrings.historyClearConfirm,
            style: TextStyle(color: AppColors.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(c, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
            ),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      ref.read(historyProvider.notifier).clearAll();
    }
  }
}

class _DisclaimerSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Contact & Team',
      icon: Icons.group_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),
          const Text(
            'Built for the Hackathon — Team Spectra',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.secondaryBg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.border),
            ),
            child: const Text(
              AppStrings.disclaimerNote,
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 12,
                height: 1.5,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _Section({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.primaryAccent, size: 18),
              const SizedBox(width: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
              ),
            ],
          ),
          child,
        ],
      ),
    );
  }
}
